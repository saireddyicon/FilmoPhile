from django.contrib import admin

# Register your models here.
from Account.models import register_model, user

admin.site.register(register_model)
admin.site.register(user)