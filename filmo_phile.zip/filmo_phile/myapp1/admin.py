from django.contrib import admin

# Register your models here.
from myapp1.models import Movies, acc_user, NewTrailer

admin.site.register(Movies)
admin.site.register(NewTrailer)
admin.site.register(acc_user)
