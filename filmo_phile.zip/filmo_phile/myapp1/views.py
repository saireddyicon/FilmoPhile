from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect


from myapp1.models import Movies
from django.contrib.auth.models import User
from django.contrib import messages

# Create your views here.
def MainHome(request):
    movie_list = Movies.objects.all()
    return render(request, 'Account/MainHome.html', {'movie_list': movie_list})


def register(request):
    pass


def watch(request, type_no):
    movie_present = get_object_or_404(Movies, id=type_no)
    movies_list = Movies.objects.filter(name=movie_present)
    return render(request, 'movies/movie_detail.html', {'movies_list': movies_list})


def ordermovie(request, order_no):
    if request.user.is_authenticated:
        print(request.user.is_authenticated)
        order_present = get_object_or_404(Movies, id=order_no)
        order_list = Movies.objects.filter(name=order_present)
        return render(request, 'movies/order_movie.html', {'order_list': order_list})
    else:
        messages.info(request, "You are not logged in. Please login to order")
        return redirect('login')



def ordersuccess(request, order_no):
    return render(request, 'movies/OrderSuccess.html')

def search_movies(request):
    if request.method == "POST":
        searched = request.POST['searched']
        movie_lists = Movies.objects.filter(name__contains=searched)
        if len(movie_lists)==0:
            return redirect('myapp1:search-movies')
        else:
            return render(request, 'Account/searchfn.html', {'searched': searched, 'movie_lists': movie_lists})
    else:
        return render(request, 'Account/MainHome.html')


