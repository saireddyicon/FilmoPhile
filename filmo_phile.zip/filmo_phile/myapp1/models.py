from django.contrib.auth.models import User
from django.db import models

CATEGORY_CHOICES = (
    ('A', 'ACTION'),
    ('D', 'DRAMA'),
    ('C', 'COMEDY'),
    ('R', 'ROMANCE'),
)

LANGUAGE_CHOICES = (
    ('EN', 'ENGLISH'),
    ('TE', 'TELUGU'),
    ('HI', 'HINDI'),
)
STATUS_CHOICES = (
    ('RA', 'RECENTLY ADDED'),
    ('MW', 'MOST  WATCHED'),
    ('TR', 'TOP RATED'),
)


class Movies(models.Model):
    name = models.CharField(max_length=500)
    description = models.TextField(max_length=10000, null=True, blank=True)
    image = models.ImageField(upload_to='images/', null=True, blank=True)
    movie_length = models.CharField(max_length=50, null=True, blank=True)
    year_of_production = models.CharField(max_length=100, null=True, blank=True)
    movie_price = models.CharField(max_length=100, null=True, blank=True)
    imdb_rating = models.CharField(max_length=100, null=True, blank=True)
    movie_director = models.CharField(max_length=200, null=True, blank=True)
    cast = models.CharField(max_length=1000, null=True, blank=True)
    category = models.CharField(choices=CATEGORY_CHOICES, max_length=1)
    language = models.CharField(choices=LANGUAGE_CHOICES, max_length=2)
    status = models.CharField(choices=STATUS_CHOICES, max_length=2)
    poster= models.ImageField(upload_to='images/', null=True, blank=True)

    def __str__(self):
        return self.name


class NewTrailer(models.Model):
    title = models.CharField(max_length=1000, null=True, blank=True)
    link = models.CharField(max_length=1500, null=True, blank=True)
    description = models.TextField(max_length=5000, null=True, blank=True)
    image = models.ImageField(upload_to='trailer_image', null=True, blank=True)
    image_link = models.CharField(max_length=1000, null=True, blank=True)
    date = models.DateTimeField()

    def __str__(self):
        return self.title


class acc_user(User):
    name = models.CharField
    email_id = models.EmailField('email address', unique=True)

    def __str__(self):
        return self.email_id
