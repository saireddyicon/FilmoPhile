import myapp1
from . import views
from django.urls import path, include

app_name = 'myapp1'
urlpatterns = [
    path('', views.MainHome, name='MainHome'),
    path('watch/<int:type_no>/', views.watch, name='watch'),
    path('ordermovie/<int:order_no>/', views.ordermovie, name='ordermovie'),
    path('ordermovie/<int:order_no>/ordersuccess', views.ordersuccess, name='ordersuccess'),
    path('search_movies/', views.search_movies, name='search-movies'),
]